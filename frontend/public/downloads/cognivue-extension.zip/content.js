chrome.storage.local.get(["user_id", "cognivue_user_id"], (result) => {
  const id = result.cognivue_user_id || result.user_id;
  if (id) {
    window.postMessage({ type: "COGNIVUE_EXTENSION_LINKED_USER", userId: id }, "*");
  }
});
